import 'dart:typed_data';

import '../../domain/repositories/group_repository.dart';
import '../datasources/group_remote_data_source.dart';
import '../models/group_expense_model.dart';
import '../models/group_member_model.dart';
import '../models/group_model.dart';
import '../models/group_user_model.dart';

class GroupRepositoryImpl implements GroupRepository {
  const GroupRepositoryImpl({required GroupRemoteDataSource remoteDataSource})
    : _remoteDataSource = remoteDataSource;

  final GroupRemoteDataSource _remoteDataSource;

  @override
  Future<String?> getCurrentUserId() {
    return _remoteDataSource.getCurrentUserId();
  }

  @override
  Future<GroupModel> createGroup({
    required String name,
    String? description,
    String? photoUrl,
    List<String> memberUserIds = const <String>[],
  }) {
    return _remoteDataSource.createGroup(
      name: name,
      description: description,
      photoUrl: photoUrl,
      memberUserIds: memberUserIds,
    );
  }

  @override
  Future<String> uploadGroupPhoto({
    required Uint8List bytes,
    required String fileName,
    required String contentType,
  }) {
    return _remoteDataSource.uploadGroupPhoto(
      bytes: bytes,
      fileName: fileName,
      contentType: contentType,
    );
  }

  @override
  Future<List<GroupUserModel>> searchUsers(String query) {
    return _remoteDataSource.searchUsers(query);
  }

  @override
  Future<List<GroupModel>> getGroups() {
    return _remoteDataSource.getGroups();
  }

  @override
  Future<List<GroupModel>> getUserGroups(String userId) {
    return _remoteDataSource.getUserGroups(userId);
  }

  @override
  Future<GroupModel?> getGroupById(String groupId) {
    return _remoteDataSource.getGroupById(groupId);
  }

  @override
  Future<List<GroupMemberModel>> getGroupMembers(String groupId) {
    return _remoteDataSource.getGroupMembers(groupId);
  }

  @override
  Future<List<GroupExpenseModel>> getGroupExpenses(String groupId) {
    return _remoteDataSource.getGroupExpenses(groupId);
  }

  @override
  Future<GroupMemberModel> addMember({
    required String groupId,
    required String userId,
    String? invitedBy,
    GroupMemberRole role = GroupMemberRole.member,
  }) {
    return _remoteDataSource.addMember(
      groupId: groupId,
      userId: userId,
      invitedBy: invitedBy,
      role: role,
    );
  }

  @override
  Future<void> removeMember({required String groupId, required String userId}) {
    return _remoteDataSource.removeMember(groupId: groupId, userId: userId);
  }

  @override
  Future<void> deleteGroup(String groupId) {
    return _remoteDataSource.deleteGroup(groupId);
  }
}
